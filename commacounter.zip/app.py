from flask import Flask, request
from count_comma import count_comma

app = Flask(__name__)


@app.route('/commacounter/', methods=["GET"])
def hello_world():
    response = {'error': True, 'string': "", 'answer': 0}
    try:
        text = request.args.get("text")
    except Exception:
        response = {'error': True, 'string': 'Lack of parameters', 'answer': 0}
        return response
    if len(text) == 0:
        response = {'error': True, 'string': 'Empty text', 'answer': 0}
        return response
    cnt = count_comma(text)
    response = {'error': False, 'string': "Contains " + str(cnt) + " commas.", 'answer': cnt}
    return response


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=80)
