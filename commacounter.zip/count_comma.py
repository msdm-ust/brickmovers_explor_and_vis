def count_comma(text):
    return text.count(",")
