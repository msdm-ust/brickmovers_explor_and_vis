from count_comma import count_comma


def test_count_comma():
    assert count_comma(",,,") == 3
    assert count_comma("") == 0
    assert count_comma(",") == 1
    assert count_comma("I am your father, right?") == 1
