package main

import "testing"

func TestNumAnd(t *testing.T)  {
	cnt := num_of_and("and And AND abc nad")
	if cnt!=3{
		t.Fail()
	}
}