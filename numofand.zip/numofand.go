package main

import "strings"

func num_of_and(s string)  int{
	ss:= strings.Fields(s)
	count := 0
	for _,str := range ss{

		if strings.ToLower(str)=="and"{
			count++
		}
	}
	return count

}
