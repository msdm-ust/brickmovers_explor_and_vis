package main

import "strings"

func num_palindromes(s string)  int{
	ss:= strings.Fields(s)
	count := 0
	for _,str := range ss{

		if is_palindromes(str){
			count++
		}
	}
	return count

}

func is_palindromes(s string) bool {
	length := len(s)
	l := 0
	r := length-1
	for {
		if s[l]!=s[r]{
			return false
		}
		l++
		r--
		if l>=r{
			break
		}
	}

	return true

}
