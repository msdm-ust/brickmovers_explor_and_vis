module.exports = {
    counter: function(t) {
        return t.length;
    }
}
