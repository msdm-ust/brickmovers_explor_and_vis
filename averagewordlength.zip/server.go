package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
)

func myHandle(w http.ResponseWriter, r *http.Request){
	defer r.Body.Close()
	q := r.URL.Query()
	var output = map[string]interface{}{
		"error": false,
		"string": "",
		"answer": 0,
	}
	_,ok := q["text"]
	if ok==false{ //none
		output = map[string]interface{}{
			"error": true,
			"string": "Lack of parameter",
			"answer": 0,
		}

	} else if len(q["text"][0])<=0{ //empty text
		output = map[string]interface{}{
			"error": true,
			"string": "Empty text",
			"answer": 0,
		}

	}else {//normal
		var text string = q["text"][0]
		answer := num_palindromes(text)

		output = map[string]interface{}{
			"error":  false,
			"string": "Contains " + strconv.Itoa(answer) + " palindromes",
			"answer": answer,
		}
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(output)

}


func myHandle2(w http.ResponseWriter, r *http.Request){
	defer r.Body.Close()
	q := r.URL.Query()
	var output = map[string]interface{}{
		"error": false,
		"string": "",
		"answer": 0,
	}
	_,ok := q["text"]
	if ok==false{ //none
		output = map[string]interface{}{
			"error": true,
			"string": "Lack of parameter",
			"answer": 0,
		}

	} else if len(q["text"][0])<=0{ //empty text
		output = map[string]interface{}{
			"error": true,
			"string": "Empty text",
			"answer": 0,
		}

	}else {//normal
		var text string = q["text"][0]
		answer := average_word_length(text)

		output = map[string]interface{}{
			"error":  false,
			"string": "Contains " + strconv.FormatFloat(answer,'f',5,32)+ "palindromes",
			"answer": answer,
		}
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(output)

}
func main() {
	fmt.Println("Running")
	http.HandleFunc("/",myHandle2)
	http.ListenAndServe(":80",nil)

}
