package main

import "strings"

func average_word_length(s string)float64 {
	words := strings.Fields(s)
	var count int = 0
	var num_word int= 0
	for _, word := range words{
		count += len(word)
		num_word += 1
	}

	return float64(count)/float64(num_word)

}
