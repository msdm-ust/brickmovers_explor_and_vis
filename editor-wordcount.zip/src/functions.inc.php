<?php
// get count of words - no error checking
function wordcount($text)
{
    return str_word_count($text);
}