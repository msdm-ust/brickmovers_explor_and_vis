import time
import urllib.request
import json
import logging
from flask import Flask, request
import threading

app = Flask(__name__)


def autocheck():
    logging.basicConfig(filename="./log", level="INFO", format="%(asctime)s %(filename)s [line:%(lineno)d] %(levelname)s %(message)s")
    opener = urllib.request.build_opener()
    services = {
        "numofpal": {
            "url": "http://editor.40300217.qpc.hal.davecutting.uk/numofpal?text=abc%20cba%20aac%20aca",
            "expect_result": 1,
        },
        "commacounter": {
            "url": "http://editor.40300217.qpc.hal.davecutting.uk/commacounter/?text=%2C%2C%2C",
            "expect_result": 3,
        },
        "numofand": {
            "url": "http://editor.40300217.qpc.hal.davecutting.uk/numofand?text=and%20And",
            "expect_result": 2,
        },
        "avglength": {
            "url": "http://editor.40300217.qpc.hal.davecutting.uk/averagewordlength?text=five%20band%20friends",
            "expect_result": 5,
        }
    }
    while True:
        for service_name in services.keys():
            req = urllib.request.Request(url=services[service_name]["url"], method="GET")
            try:
                res = opener.open(req)
            except Exception as e:
                logging.warning(f"{service_name} Service Unavailable")
                continue
            page_source = res.read().decode()
            j = json.loads(page_source)
            if j["error"] or j["answer"] != services[service_name]["expect_result"]:
                logging.warning(f"{service_name} Service Error")
            else:
                logging.info(f"{service_name} Service Normal")
        time.sleep(600)


@app.route('/autocheck/', methods=["GET"])
def hello_world():
    with open("./log") as f:
        return f.read()


if __name__ == '__main__':
    t = threading.Thread(target=autocheck)
    t.start()
    app.run(host="0.0.0.0", port=9499)
