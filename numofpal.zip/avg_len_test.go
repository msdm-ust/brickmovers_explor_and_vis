package main

import "testing"

func TestAvgLen(t *testing.T) {
	cnt := average_word_length("aba abc bbb a")
	if cnt!=2.5{
		t.Fail()
	}
}
