package main

import "testing"

func TestNumPal(t *testing.T) {
	cnt := num_palindromes("aba abc bb abba")
	if cnt!=3{
		t.Fail()
	}
}